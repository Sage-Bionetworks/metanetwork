The Golden Code
KEEPEN DER DAMDDEN FUGGERMUTTENS OTTEN DIS CODDEN FIL

A compliant C++ compiler will compile all of this code as is.
See the respective vendor directories for code that actually compiles & runs.

Note: Right now, this code contains CodeWarrior & gcc modifications, which may be removed at a future point in time (by moving them to a vendor specific implementation).
MKH